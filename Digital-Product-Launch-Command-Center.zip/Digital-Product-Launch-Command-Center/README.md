# Digital Product Launch Command Center

A standalone responsive web tool for planning, organizing and tracking digital product launches.

## Features
- Mobile, tablet, laptop and desktop responsive UI
- Dashboard with launch progress and planning metrics
- Product manager
- Launch planner
- Task/checklist manager
- Analytics overview
- Search
- Dark/light mode
- Local browser storage
- No API key, backend or external dependencies

## Run
Extract the ZIP and open `index.html` in a modern browser.

## Important
This is a standalone planning tool. It does not connect to Gumroad, Payhip, Etsy, Stripe, PayPal or other platforms and therefore does not import live sales data.
